<!DOCTYPE html><html lang=en><head><meta charset=utf-8><title>FIT/IoT-LAB &#8226; Very large scale open wireless sensor network testbed</title><meta name=viewport content="width=device-width,initial-scale=1,shrink-to-fit=no"><script async defer src="https://www.google.com/recaptcha/api.js?onload=vueRecaptchaApiLoaded&render=explicit"></script><script async src="https://www.googletagmanager.com/gtag/js?id=UA-115966924-1"></script><script>// no tracking for devwww
    if (window.location.hostname === 'www.iot-lab.info') {
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'UA-115966924-1');
    }</script><link href=/testbed/css/app.d838dc6e.css rel=preload as=style><link href=/testbed/css/chunk-vendors.c333d7fa.css rel=preload as=style><link href=/testbed/js/app.3dbba19f.js rel=preload as=script><link href=/testbed/js/chunk-vendors.abb22408.js rel=preload as=script><link href=/testbed/css/chunk-vendors.c333d7fa.css rel=stylesheet><link href=/testbed/css/app.d838dc6e.css rel=stylesheet></head><body><div id=app><app></app></div><script src=/testbed/js/chunk-vendors.abb22408.js></script><script src=/testbed/js/app.3dbba19f.js></script></body></html>